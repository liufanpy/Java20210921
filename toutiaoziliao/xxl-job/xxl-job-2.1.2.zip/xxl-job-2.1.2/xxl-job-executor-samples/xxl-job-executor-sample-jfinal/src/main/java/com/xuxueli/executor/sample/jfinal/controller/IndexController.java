package com.xuxueli.executor.sample.jfinal.controller;

import com.jfinal.core.Controller;

public class IndexController extends Controller {

	public void index(){
		renderText("xxl job executor running.");
	}

}
