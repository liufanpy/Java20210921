self.__precacheManifest = [
  {
    "revision": "0693fad822f4d82483c2",
    "url": "/css/404.c1f65a3d.css"
  },
  {
    "revision": "0693fad822f4d82483c2",
    "url": "/js/404.498a4ab6.js"
  },
  {
    "revision": "a4535b6fa082244e412c",
    "url": "/css/app.205236c0.css"
  },
  {
    "revision": "a4535b6fa082244e412c",
    "url": "/js/app.5e14f08a.js"
  },
  {
    "revision": "8cd837d280cb06982ff5",
    "url": "/css/chunk-vendors.ee57d822.css"
  },
  {
    "revision": "8cd837d280cb06982ff5",
    "url": "/js/chunk-vendors.3fadaa7f.js"
  },
  {
    "revision": "cc5f572d8b51a7a37f76",
    "url": "/css/dashboard.d79e92dc.css"
  },
  {
    "revision": "cc5f572d8b51a7a37f76",
    "url": "/js/dashboard.2b71d867.js"
  },
  {
    "revision": "cbd15584bb489f083e47",
    "url": "/css/form.95a06355.css"
  },
  {
    "revision": "cbd15584bb489f083e47",
    "url": "/js/form.e9466424.js"
  },
  {
    "revision": "6689f1181c95a1e5b7e1",
    "url": "/css/login.a0246602.css"
  },
  {
    "revision": "6689f1181c95a1e5b7e1",
    "url": "/js/login.c056fbb7.js"
  },
  {
    "revision": "c490da73ad84ac3c866d04f6e0a4b09c",
    "url": "/img/img_avatar@2x.c490da73.png"
  },
  {
    "revision": "8e008fb617603882baed74c332081c8e",
    "url": "/img/tanhua-logo@2x.8e008fb6.png"
  },
  {
    "revision": "d1edad672b0c3382088ec490428ba8ab",
    "url": "/img/img_teshu_nothing@2x.d1edad67.png"
  },
  {
    "revision": "0f4bc32b0f52f7cfb7d19305a6517724",
    "url": "/img/404-cloud.0f4bc32b.png"
  },
  {
    "revision": "0ae613072d30013f625d782b91a0b4ff",
    "url": "/img/login-gb@2x.0ae61307.jpg"
  },
  {
    "revision": "535877f50039c0cb49a6196a5b7517cd",
    "url": "/fonts/element-icons.535877f5.woff"
  },
  {
    "revision": "732389ded34cb9c52dd88271f1345af9",
    "url": "/fonts/element-icons.732389de.ttf"
  },
  {
    "revision": "a57b6f31fa77c50f14d756711dea4158",
    "url": "/img/404.a57b6f31.png"
  },
  {
    "revision": "072eb55c9573ed6957ccdc46639f959e",
    "url": "/img/sidebar-touxiang@2x.072eb55c.png"
  },
  {
    "revision": "ee9091dbd191b2e3a80519c0e1193e70",
    "url": "/img/login-logo@2x.ee9091db.png"
  },
  {
    "revision": "46ac6629168546c71dbf115992aa4be9",
    "url": "/fonts/VideoJS.46ac6629.eot"
  },
  {
    "revision": "82ed34356d672e28c2cd3760eff47bd0",
    "url": "/index.html"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
];