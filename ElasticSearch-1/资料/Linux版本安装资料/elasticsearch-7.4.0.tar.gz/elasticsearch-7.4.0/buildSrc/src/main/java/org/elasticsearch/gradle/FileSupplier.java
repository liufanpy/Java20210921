package org.elasticsearch.gradle;

import java.io.File;
import java.util.function.Supplier;

public interface FileSupplier extends Supplier<File> {
}
