import java.io.File;

public class TestingIO {
    public TestingIO() {
        new File("foo");
    }
}

